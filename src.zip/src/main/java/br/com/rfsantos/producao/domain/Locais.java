package br.com.rfsantos.producao.domain;


import org.springframework.data.jpa.repository.JpaRepository;

public interface Locais extends JpaRepository<Local, Long> {

}
