package br.com.rfsantos.producao;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProducaoSBApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProducaoSBApplication.class, args);
		
	}

}
