package br.com.rfsantos.tabelas;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2020-12-08T14:02:27.586-0300")
@StaticMetamodel(Defeito.class)
public class Defeito_ {
	public static volatile SingularAttribute<Defeito, Long> td01DefeitoId;
	public static volatile SingularAttribute<Defeito, String> td01Descricao;
	public static volatile SingularAttribute<Defeito, String> td01Ean;
	public static volatile SingularAttribute<Defeito, String> td01Grupo;
}
