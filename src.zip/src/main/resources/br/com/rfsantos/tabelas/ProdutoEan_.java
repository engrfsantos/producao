package br.com.rfsantos.tabelas;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2020-12-08T14:02:28.257-0300")
@StaticMetamodel(ProdutoEan.class)
public class ProdutoEan_ {
	public static volatile SingularAttribute<ProdutoEan, String> codProduto;
	public static volatile SingularAttribute<ProdutoEan, String> descricao;
	public static volatile SingularAttribute<ProdutoEan, String> ean;
	public static volatile SingularAttribute<ProdutoEan, String> familia;
}
