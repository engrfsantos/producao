package br.com.rfsantos.tabelas;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2020-12-08T14:02:28.087-0300")
@StaticMetamodel(Identificador.class)
public class Identificador_ {
	public static volatile SingularAttribute<Identificador, String> td01Id;
	public static volatile SingularAttribute<Identificador, String> td01DescBreve;
	public static volatile SingularAttribute<Identificador, String> td01Descricao;
	public static volatile SingularAttribute<Identificador, String> td01Local;
	public static volatile SingularAttribute<Identificador, String> td01Status;
}
