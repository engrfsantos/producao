package br.com.rfsantos.tabelas;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2020-12-08T14:02:28.273-0300")
@StaticMetamodel(Tabela.class)
public class Tabela_ {
	public static volatile SingularAttribute<Tabela, String> ts01Tabela;
	public static volatile SingularAttribute<Tabela, String> ts01Tipo;
}
