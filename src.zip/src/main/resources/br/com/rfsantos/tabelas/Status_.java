package br.com.rfsantos.tabelas;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2020-12-08T14:02:28.265-0300")
@StaticMetamodel(Status.class)
public class Status_ {
	public static volatile SingularAttribute<Status, Integer> ts01Status;
	public static volatile SingularAttribute<Status, String> ts01DescBreve;
	public static volatile SingularAttribute<Status, String> ts01Descricao;
}
