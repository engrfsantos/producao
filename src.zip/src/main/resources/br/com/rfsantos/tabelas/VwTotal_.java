package br.com.rfsantos.tabelas;

import java.util.Date;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2020-12-08T14:02:28.289-0300")
@StaticMetamodel(VwTotal.class)
public class VwTotal_ {
	public static volatile SingularAttribute<VwTotal, String> anadef;
	public static volatile SingularAttribute<VwTotal, String> codbarras;
	public static volatile SingularAttribute<VwTotal, String> codbarrasrep;
	public static volatile SingularAttribute<VwTotal, String> codigo;
	public static volatile SingularAttribute<VwTotal, String> def;
	public static volatile SingularAttribute<VwTotal, String> descesp;
	public static volatile SingularAttribute<VwTotal, String> descr;
	public static volatile SingularAttribute<VwTotal, Date> dt;
	public static volatile SingularAttribute<VwTotal, Date> dtrep;
	public static volatile SingularAttribute<VwTotal, String> ean;
	public static volatile SingularAttribute<VwTotal, String> eanrep;
	public static volatile SingularAttribute<VwTotal, String> grupo;
	public static volatile SingularAttribute<VwTotal, String> hora;
	public static volatile SingularAttribute<VwTotal, String> hrrep;
	public static volatile SingularAttribute<VwTotal, Long> idprod;
	public static volatile SingularAttribute<VwTotal, String> idsetor;
	public static volatile SingularAttribute<VwTotal, String> local;
	public static volatile SingularAttribute<VwTotal, String> narrativa;
	public static volatile SingularAttribute<VwTotal, String> prodcodrep;
	public static volatile SingularAttribute<VwTotal, String> proddescrep;
	public static volatile SingularAttribute<VwTotal, String> prodnarrarep;
	public static volatile SingularAttribute<VwTotal, String> reparo;
	public static volatile SingularAttribute<VwTotal, String> serial;
	public static volatile SingularAttribute<VwTotal, String> status;
	public static volatile SingularAttribute<VwTotal, String> stdef;
	public static volatile SingularAttribute<VwTotal, String> un;
	public static volatile SingularAttribute<VwTotal, String> usuario;
}
