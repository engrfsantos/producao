package br.com.rfsantos.tabelas;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2020-12-08T14:02:28.079-0300")
@StaticMetamodel(Grupo.class)
public class Grupo_ {
	public static volatile SingularAttribute<Grupo, String> ts01Grupo;
	public static volatile SingularAttribute<Grupo, String> ts01Descbrevgrupo;
	public static volatile SingularAttribute<Grupo, String> ts01Descgrupo;
}
