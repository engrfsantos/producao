package br.com.rfsantos.tabelas;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2020-12-08T14:02:28.249-0300")
@StaticMetamodel(Produto.class)
public class Produto_ {
	public static volatile SingularAttribute<Produto, String> ts01Codigo;
	public static volatile SingularAttribute<Produto, String> ts01CodBarras;
	public static volatile SingularAttribute<Produto, String> ts01DescEsp;
	public static volatile SingularAttribute<Produto, String> ts01Descricao;
	public static volatile SingularAttribute<Produto, String> ts01Grupo;
	public static volatile SingularAttribute<Produto, String> ts01Narrativa;
	public static volatile SingularAttribute<Produto, String> ts01Unidade;
}
