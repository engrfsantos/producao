package br.com.rfsantos.tabelas;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2020-12-08T14:02:28.158-0300")
@StaticMetamodel(Local.class)
public class Local_ {
	public static volatile SingularAttribute<Local, String> ts01Desc;
}
