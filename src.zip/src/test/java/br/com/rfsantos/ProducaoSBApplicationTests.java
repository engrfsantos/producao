package br.com.rfsantos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProducaoSBApplicationTests {

	@Test
	void contextLoads() {
	}

}
